
package com.unifacisa.Aula04;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class App 
{
	public static void main( String[] args ) throws JsonGenerationException, JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();

        // Serialize
        StringWriter writer = new StringWriter();
        mapper.writeValue(writer, getPessoas());
        System.out.println(writer);

        // Deserialize
        String jsonInput = "[{\"id\":1,\"nome\":\"Lucas\"},{\"id\":2,\"nome\":\"Maria\"},{\"id\":3,\"nome\":\"Jose\"}]";
        List<Pessoa> p = mapper.readValue(jsonInput, new TypeReference<List<Pessoa>>(){});
        System.out.println("Pessoa: " + p);

    }
    private static List<Pessoa> getPessoas() {

        List<Pessoa> pessoas = new ArrayList<Pessoa>();

        Pessoa p1 = new Pessoa();
        p1.setId(1);
        p1.setNome("Lucas");
        p1.setIdade(19);
        p1.setLastName("Barbosa");
        p1.setTempoLogadoHoras(1);
        p1.setAdmin(false);

        Pessoa p2 = new Pessoa();
        p2.setId(1+1);
        p2.setNome("Maria");
        p2.setIdade(21);
        p2.setLastName("Tereza");
        p2.setTempoLogadoHoras(0);
        p2.setAdmin(false);
        
        Pessoa p3 = new Pessoa();
        p3.setId(3);
        p3.setNome("Joao");
        p3.setIdade(16);
        p3.setLastName("Francisco");
        p3.setTempoLogadoHoras(8);
        p3.setAdmin(false);
        
        Pessoa p4 = new Pessoa();
        p4.setId(1+3);
        p4.setNome("Luan");
        p4.setIdade(20);
        p4.setLastName("Santos");
        p4.setTempoLogadoHoras(5453);
        p4.setAdmin(true);

        pessoas.add(p1);
        pessoas.add(p2);
        pessoas.add(p3);
        pessoas.add(p4);

        return pessoas;

    }
}
