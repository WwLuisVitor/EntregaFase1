
package com.unifacisa.Aula04;

public class Pessoa {
	
	private long id;
    private String nome;
    private String lastName;
    private long idade;
    private int tempoLogadoHoras;
    private boolean admin;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getIdade() {
		return idade;
	}
	public void setIdade(long idade) {
		this.idade = idade;
	}
	public int getTempoLogadoHoras() {
		return tempoLogadoHoras;
	}
	public void setTempoLogadoHoras(int tempoLogadoHoras) {
		this.tempoLogadoHoras = tempoLogadoHoras;
	}
	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
    
    
    
    



}
